from django.apps import AppConfig


class OrderingConfig(AppConfig):
    name = 'ordering'
